import fortnitepy
import json

# Charger la configuration
with open('config.json') as f:
    config = json.load(f)

# Créer le client Fortnite
client = fortnitepy.Client(
    email=config['email'],
    password=config['password'],
    client_id=config['client_id'],
    client_secret=config['client_secret']
)

# Définir les événements
@client.event
async def event_ready():
    print(f'Connecté en tant que {client.user.display_name}')

@client.event
async def event_party_invite(invitation):
    await invitation.accept()
    print(f'Invité par {invitation.sender.display_name}, et rejoint le lobby.')
    await client.party.me.set_ready(fortnitepy.ReadyState.READY)
    print(f'{client.user.display_name} est prêt.')

@client.event
async def event_party_member_join(member):
    print(f'{member.display_name} a rejoint le lobby.')
    if client.user.id == member.id:
        await client.party.me.set_ready(fortnitepy.ReadyState.READY)
        print(f'{client.user.display_name} est prêt.')

# Démarrer le bot
client.run()
