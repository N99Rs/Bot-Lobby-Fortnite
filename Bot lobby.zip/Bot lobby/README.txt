Creating an Epic Games Account: You will need an Epic Games account for the bot. Ideally, create a new account dedicated to this use.

Obtaining API Keys:

Registering on the Epic Games Developer Portal: Go to the Epic Games Developer Portal and register as a developer.
Creating an app: Create a new app to get your client_id and client_secret.
Installation of dependencies:

Install Python if you haven't already.
Install the necessary libraries. We will use fortnitepy, an unofficial library for interacting with the Fortnite API.
bash
Copy code
pip install fortnitepy

Now you need to edit the attached files with the corresponding information.

This will create a bot that will allow you to only play with bots in your games because the bot's purpose is to influence matchmaking.